Thanks for downloading SCG Showcase Modules! Hope you like it ^_^

This asset is fully free and cannot be saled at the Unity Asset Store, or anywhere else.
Feel free to use it everywhere you like! Providing link to the asset in the credits, will be great, bui it's not necessary.

Known bugs/issues/feautures:

[Version 1.1]
- Added material ball.

[Version 1.0]
- Asset is designed in Deffered/Linear pipeline, so it's best settings to use it.
- Main Camera using Unity 5.3 Cinematic post-effects. You can delete "Standard assets" folder from project, if you dont need them, or getting some errors in console.
- Sometimes script stops updating materials. Just hit "Apply prefab" button, and it will work.
- Script is simple, and because of that - limited. If you change something inside prefab, script will stop working in 99.9%.
- Walls modules using 2x2x2 cube UVW Simple projection, so, you can use own materials with textures, but there can be some visible seams.
