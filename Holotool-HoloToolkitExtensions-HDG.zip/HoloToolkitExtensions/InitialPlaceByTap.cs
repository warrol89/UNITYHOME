﻿using UnityEngine;
using HoloToolkit.Unity;
using HoloToolkit.Unity.InputModule;


namespace LocalJoost.HoloToolkitExtensions
{
    public class InitialPlaceByTap : MonoBehaviour, IInputClickHandler
    {
        protected AudioSource Sound;
        protected MoveByGaze GazeMover;
        public TextToSpeechManager Manager;
        private TextMesh mesh;
        protected void Start()
        {
            Sound = GetComponent<AudioSource>();
            GazeMover = GetComponent<MoveByGaze>();

            InputManager.Instance.PushFallbackInputHandler(gameObject);
        }

        public virtual void OnInputClicked(InputEventData eventData)
        {
          
          

            if (!GazeMover.IsActive)
            {
                GazeMover.IsActive = true;
                
                if (Manager != null)
                {
                    Manager.AudioSource.enabled = true;
                    if (Sound != null)
                    {

                        Sound.Play();

                    }

                    string nameGameOject = this.name;

                    var msg = string.Format("You have selected the package. Kindly move around and place the package at {0}.",nameGameOject);

                    Manager.SpeakText(msg);
                }


            }
            else if (GazeMover.IsActive)
            {
                Manager.SpeakText("The package has been placed");
                GazeMover.IsActive = false;
            }
        }

    }
}
