## [CrossPlatform]()
Wrapper scripts for Win32 and WinRT APIs in a single API call that works in the Unity editor and in a UWP application.
