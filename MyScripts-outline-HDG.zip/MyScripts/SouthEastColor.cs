﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SouthEastColor : MonoBehaviour {
    private TextMesh mesh;
    // Use this for initialization
    void Start () {

        mesh = this.gameObject.GetComponent<TextMesh>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void colorchange()
    {


        this.gameObject.GetComponent<Renderer>().material.color = Color.red;

    }

    public void Reset()
    {
        this.gameObject.GetComponent<Renderer>().material.color = new Color(1f, 1f, 1f, 1f);

    }

}
