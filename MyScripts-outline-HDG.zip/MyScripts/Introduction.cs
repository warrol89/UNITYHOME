﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using HoloToolkit.Unity;

public class Introduction : MonoBehaviour {

    public AudioSource BackGround;
    private TextToSpeechManager txttospeech;
    private string message;

    // Use this for initialization
    private void Awake()
    {
        StartCoroutine(intro());

    }

    void Start () {
      
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private IEnumerator intro()
    {
        BackGround = this.GetComponent<AudioSource>();
        if (BackGround != null)
        {

            yield return new WaitForSeconds(4);
            message = string.Format("Welcome to MIRACL! The one stop logistics solution");
            txttospeech = GetComponent<TextToSpeechManager>();
            txttospeech.SpeakText(message);
            BackGround.Play();
            yield return new WaitForSeconds(4);
            this.gameObject.SetActive(false);
        }
        else
        {
            yield return new WaitForSeconds(1);

        }

    }
}
