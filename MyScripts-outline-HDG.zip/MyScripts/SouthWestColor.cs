﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SouthWestColor : MonoBehaviour
{
    private Color color;
    // Use this for initialization
    void Start()
    {

       
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void colorchange()
    {
        var original = this.GetComponent<Renderer>().material.color;

        this.gameObject.GetComponent<Renderer>().material.color = Color.green;
        

    }

    public void Reset()
    {
        this.gameObject.GetComponent<Renderer>().material.color = new Color(1f, 1f, 1f, 1f);

    }

}
